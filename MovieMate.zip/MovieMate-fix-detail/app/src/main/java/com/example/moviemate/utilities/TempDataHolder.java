package com.example.moviemate.utilities;

public class TempDataHolder {
    public static Boolean IS_WATCHLIST_UPDATED = false;
}
